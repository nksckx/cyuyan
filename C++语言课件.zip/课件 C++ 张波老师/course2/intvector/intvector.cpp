#include <iostream>
#include <vector>

int main() {
  vector<int, allocator<int> > v;
  int i;
  for(i = 0; i < 10; i++)
    v.push_back(i);
  for(i = 0; i < v.size(); i++)
    cout << v[i] << ", ";
  cout << endl;
  for(i = 0; i < v.size(); i++)
    v[i] = v[i] * 10; // Assignment  
  for(i = 0; i < v.size(); i++)
    cout << v[i] << ", ";
  cout << endl;
} ///:~
