#include <iostream>
#include <fstream>
#include <vector>
#include <string>

main()
{
  ifstream book("TIC2Vone.txt");
  string word, str;
  vector <string, allocator<string> > v;
  cout << "please input the word you want to search: "; 
  cin >> word;
  int found = 0; 
  while ( book >> str ) {
	  v.push_back(str);
      if ( str == word ) found=1;
	  //cout << "[" << str <<"]" << endl;
	  if ( str[str.size()-1] == '.' && found ) break;
      if ( str[str.size()-1] == '.' ) v.clear();
  }
  for (int i=0; i<v.size(); i++)
	  cout << v[i] << " ";
  cout << endl;

}