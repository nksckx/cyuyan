#include <string>
#include <iostream>
#include <fstream>
#include <vector>

int main()
{
  vector<string, allocator<string> > v;
  ifstream in("Fillvector.cpp");
  string line;
  while(getline(in, line))
    v.push_back(line); // Add the line to the end
  // Add line numbers:
  for(int i = 0; i < v.size(); i++)
    cout << i << ": " << v[i] << endl;
  
} ///:~
