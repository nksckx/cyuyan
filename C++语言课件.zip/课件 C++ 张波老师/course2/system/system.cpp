#include <iostream.h>
#include <stdlib.h>
#include <string.h>
int main()
{  char cmd[100];

   do{
	  cout << "this is my OS-shell, input: ";
	  cin >> cmd;
	  system(cmd);
   } while (strcmp(cmd, "exit") !=0 );
}