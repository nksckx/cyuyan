#include <iostream>
#include <string>
#include <fstream>
#include <set>
using namespace std;
main()
{
   set<string> wordSet;
   ifstream inf("TIC2Vone.txt");
   while (inf) {
	   string word;
	   inf >> word;
	   wordSet.insert( word );
   }
   cout << "the book has " << wordSet.size() 
	    << " different words" << endl;
}
