// ShapeDemoView.cpp : implementation of the CShapeDemoView class
//

#include "stdafx.h"
#include "ShapeDemo.h"

#include "ShapeDemoDoc.h"
#include "ShapeDemoView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CShapeDemoView

IMPLEMENT_DYNCREATE(CShapeDemoView, CView)

BEGIN_MESSAGE_MAP(CShapeDemoView, CView)
	//{{AFX_MSG_MAP(CShapeDemoView)
	ON_WM_LBUTTONDOWN()
	ON_WM_RBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CShapeDemoView construction/destruction

CShapeDemoView::CShapeDemoView()
{
	// TODO: add construction code here

}

CShapeDemoView::~CShapeDemoView()
{
}

BOOL CShapeDemoView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CShapeDemoView drawing

void CShapeDemoView::OnDraw(CDC* pDC)
{
	CShapeDemoDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
}



/////////////////////////////////////////////////////////////////////////////
// CShapeDemoView diagnostics

#ifdef _DEBUG
void CShapeDemoView::AssertValid() const
{
	CView::AssertValid();
}

void CShapeDemoView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CShapeDemoDoc* CShapeDemoView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CShapeDemoDoc)));
	return (CShapeDemoDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CShapeDemoView message handlers


/**************************************************************
�����Ǽ���ȥ�ĺ���
**************************************************************/

void CShapeDemoView::animation(Shape &s, CDC *pDC)
{
   for (int i=30; i<400; i++) 
   {
	 s.SetPosition(i, i);
	 s.Draw(RGB(255, 1, 1), pDC);
	 Sleep(10);
	 s.Draw(RGB(255, 255, 255), pDC);
   }
}

void CShapeDemoView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default

	CClientDC DC(this);
	
	Circle c;
	Rect r;
	Triangular tri;

	animation(c, &DC);
	animation(r, &DC);
	animation(tri, &DC);
	
	CView::OnLButtonDown(nFlags, point);
//	PostQuitMessage(0);	
}
