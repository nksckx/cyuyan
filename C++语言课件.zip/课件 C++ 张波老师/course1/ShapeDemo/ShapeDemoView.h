// ShapeDemoView.h : interface of the CShapeDemoView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SHAPEDEMOVIEW_H__13CDB003_6CC3_43CC_A37C_493BA046833D__INCLUDED_)
#define AFX_SHAPEDEMOVIEW_H__13CDB003_6CC3_43CC_A37C_493BA046833D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "shapes.h"

class CShapeDemoView : public CView
{
protected: // create from serialization only
	CShapeDemoView();
	DECLARE_DYNCREATE(CShapeDemoView)

// Attributes
public:
	CShapeDemoDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CShapeDemoView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CShapeDemoView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CShapeDemoView)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);

	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	void animation(Shape & s, CDC *pDC);

};

#ifndef _DEBUG  // debug version in ShapeDemoView.cpp
inline CShapeDemoDoc* CShapeDemoView::GetDocument()
   { return (CShapeDemoDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SHAPEDEMOVIEW_H__13CDB003_6CC3_43CC_A37C_493BA046833D__INCLUDED_)
