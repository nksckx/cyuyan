// stdafx.cpp : source file that includes just the standard includes
//	rubik.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information
//
// 
// This software is licensed/distributed under the GPL 
// WITHOUT ANY WARRANTY - see gpl.license.txt for details
// Written by Ross Wolin/Mystic Industries - Copyright 2003
//

#include "stdafx.h"



