//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by rubik.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_RUBIKTYPE                   129
#define IDD_SCRAMBLE                    130
#define IDD_PREFERENCES                 131
#define IDT_BUILD_DATE                  1000
#define IDE_ROT_COUNT                   1001
#define IDC_SHOW_ROTATIONS              1002
#define IDE_MOUSE_REJECT_ANGLE          1003
#define IDE_MOUSE_REJECT_LENGTH         1004
#define IDB_DEFAULTS                    1005
#define IDE_ROTATION_INCREMENTS         1006
#define IDE_ROTATION_DELAY              1007
#define IDC_SWAP_BUTTONS                1008
#define IDM_HELP_CONTENTS               32793
#define IDM_SCRAMBLE                    32794
#define IDM_PREFERENCES                 32795
#define ID_INDICATOR_MOVE_COUNT         59142

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32796
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
