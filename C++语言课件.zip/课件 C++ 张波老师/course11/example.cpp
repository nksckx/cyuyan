#include <stdlib.h> 
#include "matlab.hpp"

int main(void)
{ 
  	mwArray img;
	load("zhumulama1.mat", "zhumulama1", &img);	
	cout << img.Size(1) << " x  " << img.Size(2) << endl;
	for (int row=1; row<= img.Size(1); row++) {
		for (int col=1; col<= img.Size(2); col++) {
				img(row, col, 1) =0;
		}
	}	
	save("zhumulama2.mat", "zhumulama2", img);	    

    return 0;
}