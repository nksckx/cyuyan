#include <iostream>
#include <fstream>
#include <string>
#include <strstream>
#include <cassert>
using namespace std;

int main() {  
  char * fname="test.rar";
  ifstream in(fname, ios::binary);  
  assert(in); 

  const int FRAGSIZE=100000;
  char * buff=new char [FRAGSIZE];
  int counter=1;
  /* Have problem. Will be studied later
  do{	  
	  // costruct the file name
 	  ostrstream outfname;
	  outfname << fname << "-" << counter++ <<ends;
	  cout << "writing " << outfname.str() << endl;

      ofstream out(outfname.str() );
	  if (in.read(buff, FRAGSIZE))
	    out.write(buff,in.gcount());	  
	  else break;
	  out.close();
  }while (1);
  */
  delete []buff;
}
