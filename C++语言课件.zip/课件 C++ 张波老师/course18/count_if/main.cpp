#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
using namespace std;
struct Student {
	int num, score;
	string name;  
};
class MyCondition {
public:
	int lo, up;
	MyCondition(int p_lo, int p_up){
		lo = p_lo;  up = p_up;
	}
	bool operator () (const Student & s) {
		return ( s.score >= lo && s.score <= up );
	}
};
main()
{
	vector<Student> v;
	ifstream inf("scores.txt");
	while (inf) {
		Student s;
		inf >> s.num >> s.name >> s.score;
		if (s.name.size()==0) break;
		cout << s.name << " " << s.score << endl;		
		v.push_back(s);
	}
	size_t cnt=count_if(v.begin(), v.end(), MyCondition(80,100) );
	cout << cnt;
}

