#include <stdio.h>
#include <stdlib.h>
#include"mytype.h"


/* 
   Make index file for the "oxford.txt" dictionary.
   Format of the index file:
     file_position  word_name/phrase_name
     ...
     (the last line) total_word_number
   By zhangbo. July 19, 2000
*/
 

int ispumsa(char *buf)
{
    if(buf[strlen(buf)-1]==',')   return 1;
    if(buf[strlen(buf)-1]==';')   return 1;

    if(!strcmp(buf,"n"))          return 1;
    if(!strcmp(buf,"vb"))         return 1;
    if(!strcmp(buf,"indefinite")) return 1;
    if(!strcmp(buf,"adv"))        return 1;
    if(!strcmp(buf,"adj"))        return 1;
    if(!strcmp(buf,"prep"))       return 1;
    if(!strcmp(buf,"pron"))       return 1;
    if(!strcmp(buf,"interj"))     return 1;
    if(!strcmp(buf,"conj"))       return 1;
    return 0;
}

void remove_dot(char *buf)
 {     int i,j;
       for(j=0,i=0;i<strlen(buf);i++)
        if(buf[i]!='.')
           buf[j++]=buf[i];        /* delte '.' */
       buf[j]=buf[i];
  }

int is_word_end(char *word)
   {
       if(word[0]=='\\')  return 1; /* this means word have pronounciation */
       if(word[0]==':') return 1;
       if(word[0]=='-' && word[1]=='-') return 1;
       if((!strcmp(word,"or"))||(!strcmp(word,"also"))) return 1;
                  /* word=="or" || "also" */
       if(ispumsa(word)) return 1;
       return 0;
    }

void filter(char *word)
 {
      char temp[255];
      int  i,j;

      for(i=0,j=0;i<strlen(word);i++)
	  if(word[i]!=' ')
	     temp[j++]=word[i];
      temp[j]='\0';
      strcpy(word,temp);
 }

char line[255];
char line_ptr=-1;

int  get_line_from_file(FILE *fp)
{
    if(fgets(line,255,fp)==NULL)
      return 0;

    while(line[0] == '\n')
    { if(fgets(line,255,fp)==NULL)
       return 0; }

    line_ptr = 0;
    return 1;
  }

void get_word_from_line(char *buf)
{
    int j;
    if(line_ptr<0)
       buf[0]='\0'; 
    else
     {
       while(isspace(line[line_ptr])&&line[line_ptr]!='\n') line_ptr++;
		 /* skip white characters */
       if(line[line_ptr]=='\n')
	 { line_ptr = -1; buf[0]='\0'; return;}
       for(j=0;!isspace(line[line_ptr])&&line[line_ptr]!='\n';line_ptr++,j++)
	  buf[j] = line[line_ptr];
       if(line[line_ptr]=='\n')
	  { line_ptr = -1; } 
       buf[j]='\0';
      }
 }

#define BUFFSIZE   60000
void main(int argc,char *argv[])
{
    FILE *dictf, *txtidxf;
    char word[255], buf[255], *s, *oneline;
    UINT word_num=0;
    LONG pos, dic_size;
    int i, linenum=0, keylen;
    int ch;

    if(argc < 3)
    { fprintf(stderr,"Usage:makeidx dictionaryfile idxfile\n");
      exit(-1);
     }

    dictf   = fopen(argv[1],"r");
    txtidxf = fopen(argv[2],"w");
    if( dictf == NULL || txtidxf ==NULL )
    {
        fprintf(stderr,"file open error: %s or %s\n",
            argv[1], argv[2]);
        exit(-1);
    }
    /* since some explanation part of a word is so long,
       I must alloc a large buffer to hold it */
    oneline = malloc(BUFFSIZE);

    linenum=0;
    while (!feof(dictf)){
       /* read in the word name*/
       s=fgets(oneline, BUFFSIZE, dictf);
       if ( (s==NULL) || (strlen(oneline)<=1) ) break;
       linenum++;
       
       /* store its file_position and name into idx file*/
       oneline[strlen(oneline)-1]='\0';
       /* remove possible ending ^M, SPACE */
       for (i=strlen(oneline)-1; i>=0; i--) {
          if (iscntrl( oneline[i] ) ||
              isspace(oneline[i] )  ||
              (oneline[i] == ',' )
             )
             oneline[i]='\0';
          else
             break;
       }  
       /* check whether it is a valid word name */
       for ( i=0; i<strlen(oneline); i++)
         if (!isascii( oneline[i] ) && 
              strstr(oneline, "also")==0  &&
              strstr(oneline, "infml")==0 &&
              strstr(oneline, "(usu")==0  &&
              strstr(oneline, "(abbr")==0 &&
              strstr(oneline, "(fem")==0  &&
              strstr(oneline, "(US")==0   &&
              strstr(oneline, "(sometimes")==0 &&
              strstr(oneline, "(often")==0) {
            printf("invalid word name at line %d: %s\n", 
                   linenum, oneline);
            exit(-1);
         }

       /* calculate the length of the key of the word/phrase*/
       for (i=0; i<strlen(oneline); i++) {
          if ( ! (isalpha(oneline[i]) ||
                  isspace(oneline[i]) ||
                  oneline[i]=='-'     ||
                  oneline[i]=='\''    ||
                  oneline[i]=='/'        ))
                  break;
       }
       keylen=i;
       /* back tracking to the last non-space character*/
       while (isspace( oneline[keylen-1] ) && keylen>0) keylen--;
       if (keylen < 1){
           printf("error in word %s, keylen=%d\n", 
                oneline, keylen);
           exit(-1);
       }
       pos=ftell(dictf);
       fprintf(txtidxf,"%u %d %s\n", pos, keylen, oneline);
       word_num++;
       
       /* read and discard the explanation part*/
       s=fgets(oneline, BUFFSIZE, dictf);
       /* remove the ending End-Of-Line */
       oneline[strlen(oneline)-1]='\0';
       /* remove the possible ^M  char */
       if (iscntrl( oneline[ strlen(oneline)-1 ] ) )
         oneline[ strlen(oneline)-1 ]='\0';
       linenum++;
     }
     fprintf(txtidxf,"%d",word_num);
     fclose(dictf);
     fclose(txtidxf);
     printf("The number of words : %d \n",word_num);
     free(oneline);
}
