// This program read the oxford dictionary into a STL 
//   multimap object. 
#include <iostream>
#include <fstream>
#include <string>
#include <map>
using namespace std;

void LoadDict(multimap<string, string>&dict){
   ifstream inf("..\\data\\oxford-dos.txt"); 
   int cnt=0;
   while (inf) {
	   string word, exp;
	   getline(inf, word);	
	   getline(inf, exp); 
	   // remove the trailing space characters.
       size_t pos=word.find_last_not_of(' ');
	   word.resize(pos+1);	   
       dict.insert( pair<string,string> ( word, exp ) );	   
	   if ( ++cnt % 100 == 0 ) {
		   cout << cnt << " words loaded...\n";
		   break;
	   }
   }; 
} 

main()
{
   multimap<string, string> dict;
   LoadDict( dict );
   cout << dict.size() << endl;
   typedef multimap<string, string>::iterator IT; 
   IT it, lo, up, p;
   for (it=dict.begin(); it!=dict.end(); it=up) {       
	   lo = dict.lower_bound(it->first);
	   up = dict.upper_bound(it->first);
	   if (++lo!= up ){ 
		   cout<<it->first<<endl;
	   }
   }
}
