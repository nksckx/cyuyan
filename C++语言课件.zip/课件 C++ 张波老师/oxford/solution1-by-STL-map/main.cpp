// This program read the oxford dictionary into a STL map
// object. 
#include <iostream>
#include <fstream>
#include <string>
#include <map>
using namespace std;

void LoadDict(map<string, string>&dict){
   ifstream inf("..\\data\\oxford-dos.txt"); 
   int cnt=0;
   while (inf) {
	   string aline, word, exp;
	   getline(inf, aline);	
	   getline(inf, exp);   
	   // remove the trailing space characters.
       for (int j=0; j<aline.size() && aline[j]!=' '; j++)
	      word += aline[j];	   
       dict[word] = exp;
	   if ( ++cnt % 1000 == 0 ) {
		   cout << cnt << " words loaded...\n";		   
		   //break;
	   }
   }; 
} 

main()
{
   map<string, string> dict;
   LoadDict( dict );
   cout << dict.size() << endl;
   string word;
   do {
	   cout << "please input the word: ";
	   cin >> word;
	   if ( word == "quit" ) break;	   
	   map<string, string>::iterator it;
	   it = dict.find(word);
	   if (it!=dict.end() )
	     cout << word << " : "<< it->second << endl;
   } while (1);
}
