
#include<stdio.h>
#include<string.h>

#define min(x,y) ((x<y)?x:y)

int cost[300][300];
int slen,dlen;

/* editdist return edit distance of two strings
      - indicate how different they are 
*/
editdistance(char *s,char *d)
{
 register int i,j,slen,dlen,temp1,temp2;

 slen = strlen(s); 
 dlen = strlen(d);

 if(*s == *d) cost[0][0] = 0;
 else cost[0][0] = 1;
 for(i=1;i<slen;i++)
     cost[i][0] = cost[i-1][0] + 1; 
 for(i=1;i<dlen;i++)
     cost[0][i] = cost[0][i-1] + 1; 
 for(i=1;i<slen;i++)
  for(j=1;j<dlen;j++)
   { temp1 = min(cost[i-1][j],cost[i][j-1]) + 1;
     temp2 = cost[i-1][j-1] + 2*(*(s+i)!=*(d+j));
     cost[i][j] = min(temp1,temp2);
     }

 return cost[i-1][j-1];
}

