/*
  Usage wrapc  Chinese_text_file target_file 
*/
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char * argv[])
{
    int cnt, Ccharcnt;
    int ch; 
    FILE *f1, *f2;
   
    if (argc != 3 ) {
       printf("Invalid usage.\n"); exit(-1);
    }
    f1 = fopen(argv[1], "r");
    f2 = fopen(argv[2], "w");
    if ( f1 == NULL || f2 ==NULL ){
       printf("file open error\n"); exit(-1);
    }

    while ( ! feof(f1) ) {
      #define COLWIDTH  58
      ch = fgetc(f1); cnt=1; 
      if(ch == EOF) break;
      if (ch > 128 ) Ccharcnt=1; else Ccharcnt=0;
      while ((char)ch != '\n' )
      {
	      if(ch == EOF) break;
	      fprintf(f2, "%c",ch);
          if (cnt % COLWIDTH == 0 ) {
             if ( Ccharcnt % 2 == 0 )
               fprintf(f2, "\n");
             else 
               cnt--;
          }
          cnt++;
          /* get a new character */
	      ch = fgetc(f1);
          if (ch > 128 ) Ccharcnt++;
      }
      fprintf(f2, "\n\n");
  }
  fclose(f1);
  fclose(f2);
}
