#include	<stdio.h>
#include	<stdlib.h>
#include	<malloc.h>
#include	<unistd.h>
#include	"dic.hh"

/*
    Revised by Heo, Junhyeok jhheo@vr.kaist.ac.kr
    For Fast Initializing and Not using up memory
    1993.3.28
    I don't know who creates the original source for eedic
      and eedic default dictionary .
*/

/* open the dictionary file and the index file 
   initialize the  similar word list.
*/
cDic::cDic (int dic_size, char *indexF, char *dicF)
{
	register int i;

	num = dic_size;

	IF = fopen(indexF,"r");
    DF = fopen(dicF,"r");
    if(IF == NULL || DF == NULL){
      fprintf(stderr,"file open error: %s or %s\n",
             indexF, dicF);
      exit(255);
    }

	for(i=0;i<30;i++) {
		swords_head[i] = NULL;
		swords_tail[i] = NULL;
	}
}

cDic::~cDic()
{
   	fclose(IF);
   	fclose(DF);
}

char * cDic::Word(unsigned i)
{
     fseek(IF, sizeof(INDEX) * (long)i + sizeof(num), SEEK_SET);
     fread(&index, sizeof(INDEX), 1, IF);
     /*printf("%s ", index.word);*/
     return(index.word);
}

char * cDic::KeyWord(unsigned i)
{
     fseek(IF, sizeof(INDEX) * (long)i + sizeof(num), SEEK_SET);
     fread(&index, sizeof(INDEX), 1, IF);
     /*printf("%s ", index.word);*/
     return(index.keyword);
}

void cDic::Search (char *word, int *pfirstpos, int*plastpos)
{
    int pos, firstpos, lastpos;
    
	pos= cDic::BSearch(word, 0, num-1);
    if (pos < 0 ) { *pfirstpos=-1; return; };
    
    for ( firstpos=pos; firstpos >=0; firstpos--)
       if (strcmp(word, KeyWord(firstpos)) != 0) break;
       
    for ( lastpos=pos; lastpos < num; lastpos++)
       if (strcmp(word, KeyWord(lastpos)) != 0) break;
       
    *pfirstpos = firstpos+1;
    *plastpos  = lastpos-1;   
}

int   cDic::BSearch (char *word, int l, int  r)
{
	int	m = (l+r)/2;
    
	if (l > r)
		return(-1);
	else if (l == r)
	{
		if (strcmp(word, KeyWord(m)) == 0){
			return(m);
        }
		else
			return(-1);
	}
	else
	{
		if (strcmp(word, KeyWord(m)) < 0)
			return(cDic::BSearch(word, l, m-1));
		else if (strcmp(word, KeyWord(m)) > 0)
			return(cDic::BSearch(word, m+1, r));
		else
			return(m);
	}
}

int  cDic::BSearch1 (char *word, int  l, int  r)
{
	int	m = (l+r)/2;

	if (l > r)
		return(-1);
	else if (l == r)
	{
		if (strncmp(word,Word(m),strlen(word)) == 0)
			return(m);
		else
			return(-1);
	}
	else
	{
		if (strncmp(word,Word(m),strlen(word)) < 0)
			return(cDic::BSearch(word,l,m-1));
		else if (strncmp(word,Word(m),strlen(word)) > 0)
			return(cDic::BSearch(word,m+1,r));
		else
			return(m);
	}
}

void cDic::PrintItem(int  firstpos, int lastpos)
{
	LONG pos;
	int ch, i, cnt, Ccharcnt;
    char tmpfname[100]="tempexplan.txt";
    char cmdstr[100];
    FILE *tmpf;

	if (DF == NULL) return;
	if (firstpos<0  || lastpos>=num)
	     return;
    /* create a temporary file */
    tmpf=fopen(tmpfname, "wb");
    if (tmpf ==NULL) {
      printf("file open error\n"); exit(-1);
    }
    
    for (i=firstpos; i<=lastpos; i++) {
	  fseek(IF,sizeof(INDEX) * i + sizeof(num),SEEK_SET);
	  fread(&index,sizeof(INDEX),1,IF);
	  pos = index.pos;
      fseek(DF,pos,0);
	
	  fprintf(tmpf, "\n%s\n", index.word);
      #define COLWIDTH  58
      ch = fgetc(DF); cnt=1; 
      if (ch > 128 ) Ccharcnt=1; else Ccharcnt=0;
	  while ((char)ch != '\n' )
	  {
	      if(ch == EOF) break;
	      fprintf(tmpf, "%c",ch);
          if (cnt % COLWIDTH == 0 ) {
             if ( Ccharcnt % 2 == 0 )
               fprintf(tmpf, "\n");
             else 
               cnt--;
          }
          cnt++;
          /* get a new character */
	      ch = fgetc(DF);
          if (ch > 128 ) Ccharcnt++;
	  }
	  fprintf(tmpf, "\n\n");
    }
    fclose(tmpf);
    sprintf(cmdstr, "more %s", tmpfname);
    system( cmdstr);
}

void cDic::PrintIndex(int i)
{
	fseek(IF,sizeof(INDEX) * i,SEEK_SET);
	fread(&index,sizeof(INDEX),1,IF);
	printf("[%s]\t%d\n", index.word, index.pos);
}

extern editdistance(char *,char *);

void cDic::SimilarWords(char *w,char c)
{
	register unsigned i,dist_bound,temp;
	char *sw,notdone;

 	dist_bound = strlen(w) >> 1;
 	notdone=2;
	for(i=1; i<num; i++) {
	 	sw = Word(i);
	 	if (c)
	 	  { if (c!=*sw) 
	 	        { if(notdone==1) break; 
	 	          else continue; }
	 	    else if(notdone==2) 
	 	        notdone--;
	 	    }
		temp = editdistance(w,sw);
		if(temp <= dist_bound) {
			if(swords_tail[temp])
			  swords_tail[temp] = (*swords_tail[temp]).append(sw);
			else
			{ swords_head[temp]=new wList(sw);
			  swords_tail[temp]=swords_head[temp];
			  }
		  }
	}

	for(i=dist_bound; i>0; i--) 
	{ if(swords_head[i]) 
	  	(*swords_head[i]).printwords();
           
        }

	for(i=1;i<=dist_bound;i++) 
	 { if(swords_head[i])
	 	{ delete swords_head[i];
	 	  swords_head[i] = NULL;
	 	  swords_tail[i] = NULL;
	 	  }
     }
 }
