#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include "mytype.h"

extern UINT DicSize;
extern LONG EODic;

class wList
{
  char *word;
  wList *next;
    public:
    wList (char *w)
  {
	word = (char *) malloc (sizeof (char) * (strlen (w) + 1));
	if (word)
	    strcpy (word, w);
	  next = NULL;
  }
   ~wList ()
  {
	if (next)
	  delete next;
	else
	  {
		if (word)
		  free (word);
	  }
  }
  wList *append (char *w)
  {
	if (next)
	  return ((*next).append (w));
	else
	  {
		next = new wList (w);
		return next;
	  }
  }
  wList *printaword ()
  {
	if (word)
	  printf ("%s ", word);
	return (next);
  }
  void printwords ()
  {
	if (next != NULL)
	  {
		if (word)
		  printf ("%s\n", word);
		(*next).printwords ();
	  }
	else
	  {
		if (word)
		  printf ("%s \n", word);
	  }
  }


};


class cDic
{
  unsigned num;
  INDEX index;
  FILE *DF, *IF;
  wList *swords_head[30];
  wList *swords_tail[30];
    public:
    cDic (int dic_size, char *indexF, char *dicF);
   ~cDic ();
  char *Word (unsigned i);
  char *KeyWord(unsigned i);
  void Search (char *word, int *pfirstpos, int*plastpos);
  int BSearch (char *word, int l, int r);
  int BSearch1 (char *word, int l, int r);
  void PrintItem(int  firstpos, int lastpos);
  void PrintIndex (int i);
  void SimilarWords (char *word, char c);
};
