#ifndef __MYTYPE_H_
#define __MYTYPE_H_
typedef int LONG;
typedef unsigned short UINT;
typedef struct {
     char word[150];
     char keyword[100];
     int  keylen;
     long pos;
} INDEX;

#endif
