/*
  The main program of my oxford dictionary.
*/

#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <unistd.h>
#include "dic.hh"

/*
     Revised By Heo, Junhyeok   jhheo@vr.kaist.ac.kr
     For Fast initializing and Not using up memory 
     1993.3.28
*/

#define WORD_MAXSIZE 2000
#define ANS_MAXSIZE  10

UINT DicSize;  /* number of words */
LONG EODic;    /* length of index file */
int  isLog=0;    /* 1: log into file newwords.txt */

/* set DicSize and EODic.
*/
void set_DicSize_and_EODic(char *idxfname)
{
     FILE *idxf;
     LONG  pos;
     
     if((idxf=fopen(idxfname,"rb"))==NULL) {
       fprintf(stderr,"No dictionary index file %s\n",idxfname);
	   exit(-1);
     }
     fread(&DicSize,sizeof(UINT),1,idxf);
     fseek(idxf,0L,SEEK_END);
     EODic=ftell(idxf);
     fclose(idxf); 
}

void GetWord(char *word)
{
  do{
    if ( isLog == 1 )
       printf("==> ");
    else
       printf("--> ");
    printf("Enter word : "); 
      
    fgets(word,WORD_MAXSIZE,stdin); word[strlen(word)-1]='\0';
    if ( strcmp(word,"*l") == 0){
      if (isLog==0) {
         printf("logging into newwords.txt\n");
         isLog =1 ;
      }else{
         printf("logging disabled\n");
         isLog = 0;
      }
    }
  }while (strcmp(word,"*L") == 0);
}

main (void)
{
	int   pos, firstpos, lastpos;
	char	word[WORD_MAXSIZE], *p;
	char	ans[ANS_MAXSIZE];
	char	dictfname[256];
	char	dictidxfname[256];
    char    cmdStr[256];
    
    printf("oxford dictionary, by zhang bo.\n*l to disable logging into \"newwords.txt\"\n");
    printf("*[space] to add your own notes\n");
    strcpy (dictfname, "oxford.txt" );
    strcpy (dictidxfname, "oxford.idxbin");

    set_DicSize_and_EODic(dictidxfname);
    cDic dictionary( (int)DicSize, dictidxfname, dictfname);

    GetWord(word);
	while (word[0]!='\0') 
	{
        if (word[0] == '*') {
            /* add my own notes */
            p = word; 
            sprintf(cmdStr, "date +%D > tem.txt; read date < tem.txt; echo $date '  %s' >> newwords.txt", p );
            system(cmdStr);
            GetWord(word);
            continue;
        }
		dictionary.Search(word, &firstpos, &lastpos);
		if(firstpos<0) {
		  printf("Similar word(s) with [ %s ] is/are:\n", word); 
          if(ans[0]=='y')
     	      dictionary.SimilarWords(word,*word);
		  else
              dictionary.SimilarWords(word,0);
          printf("\n"); 
        }else{
          dictionary.PrintItem(firstpos, lastpos);
  
          /* if isLog==1, append the word into file newwords.txt */
          if (isLog) {
            sprintf(cmdStr, "date +%D > tem.txt; read date < tem.txt; echo $date '  %s' >> newwords.txt", word );
            system(cmdStr);
          }
        }
        GetWord(word);
	}
}

