// cheng gong shen ban au yun * shen = 
//  shen ban ao yun cheng gong.  ��ͬ���ֶ�Ӧ��ͬ����

#include <stdio.h>

main ()
{

	for (long n=100000; n<=999999; n++) {
	    int cheng, gong, shen, ban, ao, yun;

		cheng = n/100000;
		gong  = (n%100000) / 10000;
		shen  = (n%10000) / 1000;
		ban   = (n%1000) / 100;
		ao    = (n%100) / 10;
		yun   = (n%10);
			

		long int result = shen * 100000 + ban * 10000 + ao * 1000 + yun * 100 + cheng * 10 + gong;
				
		if ( n * shen == result )
			printf("%d\n", n);
		//printf("%d\n", n);
	}

}