#include <board.h>
#include <math.h>
using namespace LibBoard;

main()
{
	 Board board;
	 
   int i, j;
   double center_x  = 1000,  center_y = 1000,  circle_R=500;
   double A_x, A_y, B_x, B_y, points;
   
	 board << Circle((int)center_x, (int)center_y, (int)circle_R, 
	 		Color::Black, Color::None, 1);
	 
   points=15;
   for ( i=0; i<15; i++) {
      A_x =  center_x + cos( i * 2 * 3.1415926 / points ) * circle_R;
      A_y =  center_y + sin( i * 2 * 3.1415926 / points ) * circle_R;
      for (j=0; j<15; j++) {
			   B_x = center_x + cos( j * 2 * 3.1415926 / points ) * circle_R;
			   B_y = center_y + sin( j * 2 * 3.1415926 / points ) * circle_R;
			   board << Line( (int)A_x, (int)A_y, (int)B_x, (int)B_y,  Color::Black, 1);
      }
   }

	 board.saveSVG("circle.svg");
   return 0;
}