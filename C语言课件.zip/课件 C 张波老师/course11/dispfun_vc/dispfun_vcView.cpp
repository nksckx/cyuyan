// dispfun_vcView.cpp : implementation of the CDispfun_vcView class
//

#include "stdafx.h"
#include "dispfun_vc.h"

#include "dispfun_vcDoc.h"
#include "dispfun_vcView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDispfun_vcView

IMPLEMENT_DYNCREATE(CDispfun_vcView, CView)

BEGIN_MESSAGE_MAP(CDispfun_vcView, CView)
	//{{AFX_MSG_MAP(CDispfun_vcView)
	ON_COMMAND(ID_FUNCTION1, OnFunction1)
	ON_COMMAND(ID_FUNCTION2, OnFunction2)
	ON_COMMAND(ID_FUNCTION3, OnFunction3)
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDispfun_vcView construction/destruction

CDispfun_vcView::CDispfun_vcView()
{
	// TODO: add construction code here

}

CDispfun_vcView::~CDispfun_vcView()
{
}

BOOL CDispfun_vcView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CDispfun_vcView drawing


/////////////////////////////////////////////////////////////////////////////
// CDispfun_vcView printing

BOOL CDispfun_vcView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CDispfun_vcView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CDispfun_vcView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CDispfun_vcView diagnostics

#ifdef _DEBUG
void CDispfun_vcView::AssertValid() const
{
	CView::AssertValid();
}

void CDispfun_vcView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CDispfun_vcDoc* CDispfun_vcView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDispfun_vcDoc)));
	return (CDispfun_vcDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDispfun_vcView message handlers

double func1(double x)
{
   return 3 * x;
}
double func2(double x)
{
   return x * x;
}
double func3(double x)
{
   return x * x * x;
} 

void CDispfun_vcView::OnFunction1() 
{
	cur_function_pointer = func1;
	InvalidateRect(NULL, true);
}

void CDispfun_vcView::OnFunction2() 
{
	cur_function_pointer = func2;
	InvalidateRect(NULL, true);	
}

void CDispfun_vcView::OnFunction3() 
{
	cur_function_pointer = func3;
	InvalidateRect(NULL, true);	
}

int CDispfun_vcView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	cur_function_pointer = func1;	
	return 0;
}

void CDispfun_vcView::OnDraw(CDC* pDC)
{	
	int xpos, origx=200, origy=300;
	char *title="function curve";
	double x, y;	

	pDC->MoveTo(origx, origy);
	pDC->LineTo(origx+300, origy);
	pDC->MoveTo(origx, origy);
	pDC->LineTo(origx, origy-200);

	for (x=0, xpos=origx; x<10; x+=0.05, xpos++){
	   y = (*cur_function_pointer) (x);
	   pDC->SetPixel((int)xpos,  (int)(origy-y), RGB(0,0,0) );	   
	}
	pDC->TextOut(xpos,origy+10, title, strlen(title));

}

