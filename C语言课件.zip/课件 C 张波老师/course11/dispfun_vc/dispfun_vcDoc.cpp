// dispfun_vcDoc.cpp : implementation of the CDispfun_vcDoc class
//

#include "stdafx.h"
#include "dispfun_vc.h"

#include "dispfun_vcDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDispfun_vcDoc

IMPLEMENT_DYNCREATE(CDispfun_vcDoc, CDocument)

BEGIN_MESSAGE_MAP(CDispfun_vcDoc, CDocument)
	//{{AFX_MSG_MAP(CDispfun_vcDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDispfun_vcDoc construction/destruction

CDispfun_vcDoc::CDispfun_vcDoc()
{
	// TODO: add one-time construction code here

}

CDispfun_vcDoc::~CDispfun_vcDoc()
{
}

BOOL CDispfun_vcDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CDispfun_vcDoc serialization

void CDispfun_vcDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CDispfun_vcDoc diagnostics

#ifdef _DEBUG
void CDispfun_vcDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CDispfun_vcDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDispfun_vcDoc commands
