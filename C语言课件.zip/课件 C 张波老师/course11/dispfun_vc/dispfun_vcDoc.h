// dispfun_vcDoc.h : interface of the CDispfun_vcDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DISPFUN_VCDOC_H__8F92F12A_763B_40C3_B495_469870AFCE63__INCLUDED_)
#define AFX_DISPFUN_VCDOC_H__8F92F12A_763B_40C3_B495_469870AFCE63__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CDispfun_vcDoc : public CDocument
{
protected: // create from serialization only
	CDispfun_vcDoc();
	DECLARE_DYNCREATE(CDispfun_vcDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDispfun_vcDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDispfun_vcDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CDispfun_vcDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DISPFUN_VCDOC_H__8F92F12A_763B_40C3_B495_469870AFCE63__INCLUDED_)
