// dispfun_vcView.h : interface of the CDispfun_vcView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DISPFUN_VCVIEW_H__36848AB5_1347_43C8_870F_C221B20BA0F3__INCLUDED_)
#define AFX_DISPFUN_VCVIEW_H__36848AB5_1347_43C8_870F_C221B20BA0F3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CDispfun_vcView : public CView
{
protected: // create from serialization only
	CDispfun_vcView();
	DECLARE_DYNCREATE(CDispfun_vcView)

// Attributes
public:
	CDispfun_vcDoc* GetDocument();
	double (*cur_function_pointer) (double);

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDispfun_vcView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDispfun_vcView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CDispfun_vcView)
	afx_msg void OnFunction1();
	afx_msg void OnFunction2();
	afx_msg void OnFunction3();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in dispfun_vcView.cpp
inline CDispfun_vcDoc* CDispfun_vcView::GetDocument()
   { return (CDispfun_vcDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DISPFUN_VCVIEW_H__36848AB5_1347_43C8_870F_C221B20BA0F3__INCLUDED_)
