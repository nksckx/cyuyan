/* The input image is in RAW format. The whole file has 
   three sections: R section, G section and B section. 
   Within each section, one byte is used to represent the
   color.
*/
#include <stdio.h>
#include <stdlib.h>

#define W  300
#define H  400
void sort(char x[ ], int n)
{
	int i,j,k;
	char t;
	for (i=0; i<n-1; i++) {
         k=i;
		for (j=i+1; j<n; j++)  
			if (x[j]>x[k])  k=j;
		if ( k!=i) {
		    t=x[i];  x[i]=x[k]; x[k]=t;
		}
	}
}
void medfilt2(char * p1, char * p2, int width, int heigh)
{	int i, j, offset;
	char colors[9], *p;
	for (i=2; i<heigh-2; i++)
		for (j=2; j<width-2; j++){
			offset = i * width + j; p=p1+offset-width-1;
              colors[0]=*p++; colors[1]=*p++; colors[2]=*p;
			p=p1+offset-1;
			colors[3]=*p++;colors[4]=*p++; colors[5]=*p;
			p=p1+offset+width-1;
			colors[6]=*p++; colors[7]=*p++;  colors[8]=*p;
			sort(colors, 9); *(p2+offset)=colors[4];
		}
}
main()
{	FILE *f1, *f2; 	char * p1, *p2; 	long fsize;

	f1=fopen("hr1-n.raw", "rb");
    f2=fopen("hr1-c.raw", "wb");
	if (f1==NULL || f2==NULL) {
           printf("file open error\n"); exit(-1);  };
	fseek(f1, 0, SEEK_END);	fsize=ftell (f1); 
	fseek(f1, 0, SEEK_SET);
	p1=(char *) malloc(fsize);	p2=(char *) malloc(fsize);
	if (p1==NULL || p2==NULL) {
            printf("memory error\n"); exit(-1); };
	fread(p1, fsize, 1, f1);
	medfilt2(p1,       p2,      W, H);
	medfilt2(p1+W*H,   p2+W*H,  W, H);
	medfilt2(p1+W*H*2, p2+W*H*2, W, H);

	fwrite(p2, fsize, 1, f2);
	free(p1); free(p2);
	fclose(f1); fclose(f2);
}
