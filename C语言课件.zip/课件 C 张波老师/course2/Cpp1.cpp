#include <stdio.h>

main()
{
	printf("Good morning!\n");
}
