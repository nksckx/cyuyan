#include <stdio.h>

main()
{
	printf("Good morning!\n");
	printf("���Ϻã�\n");
}
