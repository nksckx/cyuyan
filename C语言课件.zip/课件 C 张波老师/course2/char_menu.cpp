#include <stdio.h>
main( )
{ 
	unsigned char c;
    printf("Please input your choice:\n");
    printf("P -- Play the game\n");
	printf("S -- Save the game\n");
    printf("R -- Restore the game\n");
    printf("Q -- Quit the game\n");

	c = getchar();
	if (c=='P' || c=='p') {
		printf("The game is to be started!\n");
	}
    //...
}
